import { Component, OnInit } from '@angular/core';
import { URLHelper } from '../URLHelper';
import { Router } from '@angular/router';
import {AuthService} from '../auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  urls = URLHelper.urls;
  currentURLs = URLHelper.urls;
  products;

  constructor(private router: Router, private authService:AuthService) { }

  ngOnInit() {
  }

  logout() {
    debugger
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    this.urls.login = true;
    this.urls.register = true;
    this.urls.logout = false;

    this.router.navigate(['']);
  }


}
