import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  name;
  username;
  constructor(private route:ActivatedRoute) { }

  ngOnInit() {

    this.username=localStorage.getItem('username');
   
  }

}
