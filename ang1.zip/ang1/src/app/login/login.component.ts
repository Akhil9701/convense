import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { LoginService } from '../login.service';
import { AuthService } from '../auth.service';

import { Router } from "@angular/router";
import { URLHelper } from '../URLHelper';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: FormGroup;
  submitted = false;
  resp;
  urls = URLHelper.urls;

  constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthService) { }

  ngOnInit() {
    this.login = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.minLength(4)]],
      // email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      // confirm_password: ['', [Validators.required, Validators.minLength(6)]],

    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.login.controls; }

  

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.login.invalid) {
      return;
    }

    this.authService.loginUser(this.login.value).subscribe(
      (response) => {
        this.resp = response;
        // alert(this.resp.message);
        console.log(this.resp);
        localStorage.setItem('token', this.resp.token);
        localStorage.setItem('username',this.resp.username);
        if (this.resp.message == "Login Successful") {
          this.urls.login = false;
          this.urls.register = false;
          this.urls.logout = true;
          this.router.navigate(['/userhome', { "name": "User" }]);
        }
        else {
          alert('invalid credentials')
        }

      }
    )
    
  }
}