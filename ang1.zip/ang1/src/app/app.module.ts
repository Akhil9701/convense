import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import{HttpClientModule} from '@angular/common/http';

import { RouterModule,Routes } from '@angular/router'

import {AuthGuard} from './auth.guard';
import {AuthService} from './auth.service';

import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { NavbarComponent } from './navbar/navbar.component';
import { UserhomeComponent } from './userhome/userhome.component';



const myroutes:Routes=[
{
  path : '', component:HomepageComponent
},
{
path : 'login', component:LoginComponent
},
{
  path : 'register', component:RegisterComponent
},

{
  path : 'userhome', component:UserhomeComponent,canActivate: [AuthGuard]
},

]

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    LoginComponent, 
    RegisterComponent, 
    UserhomeComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule,FormsModule,HttpClientModule,
    RouterModule.forRoot(myroutes)
  ],
  providers: [AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
 

