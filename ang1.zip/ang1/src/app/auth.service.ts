import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient, private router: Router) { }

  registerUser(register) {
    return this.http.post("http://localhost:4900/api/register", register);
  }

  loginUser(login) {
    return this.http.post("http://localhost:4900/api/login", login);
  }

  loggedIn() {
    return !!localStorage.getItem('token');
  }
}
