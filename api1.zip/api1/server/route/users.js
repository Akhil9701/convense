var User = require("../model/user");

var Cryptr = require('cryptr');
const cryptr = new Cryptr('1559');
const jwt = require('jsonwebtoken');

exports.registerUser = function (req, res) {

    console.log(req.body);
    var username = req.body.username;
    var emailId = req.body.emailId;
    var password = req.body.password;
    //var confirmpassword = req.body.password;

    var newUser = new User({

        username: username,
        emailId: emailId,
        password: password,
        //confirmpassword
    });

    User.findOne({ emailId: emailId }, function (err, event) {
        if (err) {
            res.send({ status: false, message: "error occured while finding user", err });
            console.error(err);
        }
        else {

            if (event == null) {
                newUser.save(function (err1, result) {
                    if (err1) {
                        res.send({ status: false, message: "Cannot add user" });
                    }
                    else {
                        var encryptPassword = cryptr.encrypt(newUser.password);
                        newUser.password = encryptPassword;
                        newUser.save(result);
                        res.send({status:true,message:"Registered succesfully"});
                        console.log(result);

                        //token creation
                        // let payload = { subject: result._id };
                        // let token = jwt.sign(payload, 'secretKey');
                        // res.status(200).send({ result });
                    }
                });
            }
            else {
                res.send({ status: false, message: "User exist" });
            }
        }
    });

}

exports.loginUser = function (req, res) {

    var emailId = req.body.emailId;
    var password = req.body.password;

    User.findOne({ emailId: emailId }, function (err, obj) {
        if (err) {
            res.send({ status: false, message: "error occured while processing login request" });
            console.log(err);
        }
        else {
            if (obj == null) {
                res.send({ status: false, message: "User not registered" });
            }
            else {
                var decryptPassword = cryptr.decrypt(obj.password);
                // if(obj.password == password){
                if (decryptPassword == password) {

                    //generate token
                    let payload = { subject: obj._id };
                    let token = jwt.sign(payload, 'secretKey');
                    let username=obj.username;
                    res.send({ status: true, message: "Login Successful", token,username });
                     console.log(obj.username);
                }
                else {
                    res.send({ status: false, message: "incorrect password" });
                    // alert("incorrect password");
                    console.log(obj);
                }
            }
        }
    });

    
}


