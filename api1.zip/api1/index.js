var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var cors = require('cors');
var User = require("./server/route/users");
const session=require('express-session');
var MongoStore = require('connect-mongo')(session);

mongoose.connect("mongodb://localhost/PROJECT3");

var db = mongoose.connection;
var app = express();

app.set('port', process.env.PORT || 4900)

app.use(cors());
app.use(bodyParser.json());

var sessionOptions = {
    secret: "secret",
    resave : true,
    saveUninitialized : false,
    store: new MongoStore({
      url:"mongodb://localhost/test",
      //other advanced options
    })
  };
  
  app.use(session(sessionOptions));
  
  app.get("/", function(req, res){
    if ( !req.session.views){
      req.session.views = 1;
    }else{
      req.session.views += 1;
    }
  
    res.json({
      "status" : "ok",
      "frequency" : req.session.views
    });
  });

app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});

app.post('/api/register',User.registerUser);
app.post('/api/login',User.loginUser);


app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not strated ...')
    else
        console.log('server Started at  : http://localhost:4900')
})

